﻿namespace DulceFacil.Infraestructura.ServicioExterno
{
    public class Class1
    {

    }
}
