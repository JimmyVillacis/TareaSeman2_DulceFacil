﻿namespace DulceFacil.Infraestructura.ServiciosEmail
{
    public class Class1
    {

    }
}
