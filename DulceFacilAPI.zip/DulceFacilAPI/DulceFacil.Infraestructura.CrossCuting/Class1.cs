﻿namespace DulceFacil.Infraestructura.CrossCuting
{
    public class Class1
    {

    }
}
